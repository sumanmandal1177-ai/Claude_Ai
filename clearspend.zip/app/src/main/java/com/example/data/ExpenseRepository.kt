package com.example.data

import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class ExpenseRepository(private val expenseDao: ExpenseDao) {

    // --- Expenses Flow ---
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()

    suspend fun insertExpense(expense: Expense): Long {
        return expenseDao.insertExpense(expense)
    }

    suspend fun updateExpense(expense: Expense) {
        expenseDao.updateExpense(expense)
    }

    suspend fun deleteExpense(expense: Expense) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun deleteExpenseById(id: Long) {
        expenseDao.deleteExpenseById(id)
    }

    // --- Recurring Expenses ---
    val activeRecurringExpenses: Flow<List<RecurringExpense>> = expenseDao.getActiveRecurringExpensesFlow()

    suspend fun insertRecurringExpense(recurringExpense: RecurringExpense): Long {
        return expenseDao.insertRecurringExpense(recurringExpense)
    }

    suspend fun updateRecurringExpense(recurringExpense: RecurringExpense) {
        expenseDao.updateRecurringExpense(recurringExpense)
    }

    suspend fun deleteRecurringExpense(recurringExpense: RecurringExpense) {
        expenseDao.deleteRecurringExpense(recurringExpense)
    }

    suspend fun deleteRecurringExpenseById(id: Long) {
        expenseDao.deleteRecurringExpenseById(id)
    }

    // --- Reminders ---
    val allReminders: Flow<List<PaymentReminder>> = expenseDao.getAllReminders()

    suspend fun insertReminder(reminder: PaymentReminder): Long {
        return expenseDao.insertReminder(reminder)
    }

    suspend fun updateReminder(reminder: PaymentReminder) {
        expenseDao.updateReminder(reminder)
    }

    suspend fun deleteReminder(reminder: PaymentReminder) {
        expenseDao.deleteReminder(reminder)
    }

    suspend fun deleteReminderById(id: Long) {
        expenseDao.deleteReminderById(id)
    }

    // --- Auto-Processing Recurring Expenses ---
    suspend fun checkAndProcessRecurringExpenses(currentTimeMillis: Long = System.currentTimeMillis()) {
        val allTemplates = expenseDao.getAllRecurringExpenses()
        val zoneId = ZoneId.systemDefault()

        for (template in allTemplates) {
            if (!template.isActive) continue

            var currentNextDue = template.nextDueDate
            var lastProcessed = template.lastProcessedDate
            var modified = false

            // Loop and add instance for every past cycle that hasn't been logged yet
            while (currentNextDue <= currentTimeMillis) {
                // Log actual expense
                val instance = Expense(
                    title = "[Recurring] ${template.title}",
                    amount = template.amount,
                    category = template.category,
                    timestamp = currentNextDue,
                    isRecurringInstance = true,
                    recurringTemplateId = template.id,
                    notes = "Automatically generated recurring expense."
                )
                expenseDao.insertExpense(instance)

                lastProcessed = currentNextDue
                currentNextDue = calculateNextOccurrence(currentNextDue, template.frequency, zoneId)
                modified = true
            }

            if (modified) {
                val updatedTemplate = template.copy(
                    nextDueDate = currentNextDue,
                    lastProcessedDate = lastProcessed
                )
                expenseDao.updateRecurringExpense(updatedTemplate)
            }
        }
    }

    private fun calculateNextOccurrence(currentEpochMs: Long, frequency: String, zoneId: ZoneId): Long {
        val date = Instant.ofEpochMilli(currentEpochMs).atZone(zoneId).toLocalDate()
        val nextDate = when (frequency) {
            "Daily" -> date.plusDays(1)
            "Weekly" -> date.plusWeeks(1)
            "Monthly" -> date.plusMonths(1)
            "Yearly" -> date.plusYears(1)
            else -> date.plusMonths(1)
        }
        return nextDate.atStartOfDay(zoneId).toInstant().toEpochMilli()
    }
}
