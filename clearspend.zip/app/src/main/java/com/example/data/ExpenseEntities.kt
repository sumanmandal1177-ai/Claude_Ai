package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String, // "Food", "Shopping", "Transport", "Entertainment", "Utilities", "Rent", "Health", "Other"
    val timestamp: Long, // DateTime in milliseconds
    val isRecurringInstance: Boolean = false,
    val recurringTemplateId: Long? = null,
    val notes: String = "",
    val isIncome: Boolean = false
)

@Entity(tableName = "recurring_expenses")
data class RecurringExpense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String,
    val frequency: String, // "Daily", "Weekly", "Monthly", "Yearly"
    val startDate: Long,
    val nextDueDate: Long,
    val lastProcessedDate: Long,
    val isActive: Boolean = true
)

@Entity(tableName = "payment_reminders")
data class PaymentReminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val dueDate: Long,
    val isCompleted: Boolean = false,
    val notes: String = ""
)
