package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    // --- Expenses ---
    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Long)

    @Query("SELECT * FROM expenses WHERE timestamp BETWEEN :start AND :end ORDER BY timestamp DESC")
    suspend fun getExpensesInTimeRange(start: Long, end: Long): List<Expense>

    // --- Recurring Expenses ---
    @Query("SELECT * FROM recurring_expenses WHERE isActive = 1")
    fun getActiveRecurringExpensesFlow(): Flow<List<RecurringExpense>>

    @Query("SELECT * FROM recurring_expenses")
    suspend fun getAllRecurringExpenses(): List<RecurringExpense>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecurringExpense(recurringExpense: RecurringExpense): Long

    @Update
    suspend fun updateRecurringExpense(recurringExpense: RecurringExpense)

    @Delete
    suspend fun deleteRecurringExpense(recurringExpense: RecurringExpense)

    @Query("DELETE FROM recurring_expenses WHERE id = :id")
    suspend fun deleteRecurringExpenseById(id: Long)

    // --- Payment Reminders ---
    @Query("SELECT * FROM payment_reminders ORDER BY dueDate ASC")
    fun getAllReminders(): Flow<List<PaymentReminder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: PaymentReminder): Long

    @Update
    suspend fun updateReminder(reminder: PaymentReminder)

    @Delete
    suspend fun deleteReminder(reminder: PaymentReminder)

    @Query("DELETE FROM payment_reminders WHERE id = :id")
    suspend fun deleteReminderById(id: Long)
}
