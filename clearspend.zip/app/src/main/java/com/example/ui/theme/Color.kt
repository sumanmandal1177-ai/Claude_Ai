package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Clean & Minimal Dark Theme Colors
val CharcoalDark = Color(0xFF0F172A)     // Slate 900
val SlateSecondary = Color(0xFF1E293B)   // Slate 800
val BorderLighter = Color(0xFF334155)    // Slate 700

val MintGreenPrimary = Color(0xFF2DD4BF) // Teal 400
val ElectricSkySecondary = Color(0xFF38BDF8) // Sky 400
val WarningRose = Color(0xFFFB7185)       // Rose 400

// Light Mode Cohesive Minimal Colors
val SnowWhiteBackground = Color(0xFFF8FAFC) // Slate 50
val CleanSurface = Color(0xFFFFFFFF)
val TealPrimaryLight = Color(0xFF0D9488)    // Teal 600
val SkySecondaryLight = Color(0xFF0284C7)   // Sky 600
val DarkGrayText = Color(0xFF0F172A)
val MediumGrayText = Color(0xFF64748B)      // Slate 500
