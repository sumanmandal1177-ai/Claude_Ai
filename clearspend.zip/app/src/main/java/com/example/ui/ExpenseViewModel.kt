package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Expense
import com.example.data.ExpenseDatabase
import com.example.data.ExpenseRepository
import com.example.data.PaymentReminder
import com.example.data.RecurringExpense
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ExpenseRepository

    init {
        val database = ExpenseDatabase.getDatabase(application)
        repository = ExpenseRepository(database.expenseDao())

        // Automatically process recurring template expenses on start up
        viewModelScope.launch {
            repository.checkAndProcessRecurringExpenses()
        }
    }

    // --- State Flows ---
    val allExpenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recurringExpenses: StateFlow<List<RecurringExpense>> = repository.activeRecurringExpenses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val reminders: StateFlow<List<PaymentReminder>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filter and search elements expected directly in MainLayout
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")

    // Live search combining categories and query tokens
    val filteredExpenses: StateFlow<List<Expense>> = combine(
        allExpenses,
        selectedCategory,
        searchQuery
    ) { list, category, query ->
        list.filter { item ->
            val matchCategory = category == "All" || item.category.lowercase() == category.lowercase()
            val matchQuery = query.isEmpty() || item.title.contains(query, ignoreCase = true) || item.notes.contains(query, ignoreCase = true)
            matchCategory && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Total net balance (income - expense)
    val totalBalance: StateFlow<Double> = allExpenses
        .map { list -> 
            val income = list.filter { it.isIncome }.sumOf { it.amount }
            val expense = list.filter { !it.isIncome }.sumOf { it.amount }
            income - expense
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Gross expenses (all outflows)
    val grossExpenses: StateFlow<Double> = allExpenses
        .map { list -> list.filter { !it.isIncome }.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Received income (all inflows)
    val receivedIncome: StateFlow<Double> = allExpenses
        .map { list -> list.filter { it.isIncome }.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Category progress metrics breakdown mapping (filtered for outgoing expenses)
    val categoryBreakdown: StateFlow<Map<String, Double>> = allExpenses
        .map { list ->
            list.filter { !it.isIncome }
                .groupBy { it.category }
                .mapValues { entry -> entry.value.sumOf { it.amount } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Theme state
    val isDarkTheme = MutableStateFlow(true) // Defaults to Dark Theme as requested by the user!

    // Lock and Authenticator settings expected by lock overlays
    private val _isLocked = MutableStateFlow(true) // Locks vault initially on app entry secure startup
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    val hasBiometricSupport = MutableStateFlow(false)

    fun setLockState(locked: Boolean) {
        _isLocked.value = locked
    }

    fun verifyPin(pin: String): Boolean {
        // Simple secure local PIN fallback matching the requirements
        return pin == "1234"
    }

    // --- Database Mutators expected by MainLayout ---

    fun addExpense(title: String, amount: Double, category: String, notes: String, isIncome: Boolean = false, timestamp: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            val expense = Expense(
                title = title,
                amount = amount,
                category = category,
                timestamp = timestamp,
                isRecurringInstance = false,
                recurringTemplateId = null,
                notes = notes,
                isIncome = isIncome
            )
            repository.insertExpense(expense)
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun addRecurringExpense(title: String, amount: Double, category: String, frequency: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val template = RecurringExpense(
                title = title,
                amount = amount,
                category = category,
                frequency = frequency,
                startDate = now,
                nextDueDate = now, // Process immediately on schedule addition
                lastProcessedDate = 0L,
                isActive = true
            )
            repository.insertRecurringExpense(template)
            repository.checkAndProcessRecurringExpenses()
        }
    }

    fun deleteRecurringExpense(recurringExpense: RecurringExpense) {
        viewModelScope.launch {
            repository.deleteRecurringExpense(recurringExpense)
        }
    }

    fun addReminder(title: String, amount: Double, dueDate: Long) {
        viewModelScope.launch {
            val reminder = PaymentReminder(
                title = title,
                amount = amount,
                dueDate = dueDate,
                isCompleted = false,
                notes = ""
            )
            repository.insertReminder(reminder)
        }
    }

    fun toggleReminderCompleted(reminder: PaymentReminder) {
        viewModelScope.launch {
            val newCompleted = !reminder.isCompleted
            repository.updateReminder(reminder.copy(isCompleted = newCompleted))

            // If checked as paid, automatically log to expenditures for monthly outflow
            if (newCompleted) {
                val expense = Expense(
                    title = "[Bill Paid] ${reminder.title}",
                    amount = reminder.amount,
                    category = "Utilities",
                    timestamp = System.currentTimeMillis(),
                    isRecurringInstance = false,
                    recurringTemplateId = null,
                    notes = "Auto-recorded from completed reminder."
                )
                repository.insertExpense(expense)
            }
        }
    }

    fun deleteReminder(reminder: PaymentReminder) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
        }
    }

    /**
     * CSV output utility expected by share actions
     */
    fun exportDataToCsv(): String {
        val expenses = allExpenses.value
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val csvBuilder = StringBuilder()
        csvBuilder.append("ID,Expense Title,Amount (USD),Category,Date,Is Recurring,Is Income,Notes\n")

        for (e in expenses) {
            val dateStr = sdf.format(Date(e.timestamp))
            val escapedTitle = e.title.replace("\"", "\"\"")
            val escapedNotes = e.notes.replace("\"", "\"\"")
            csvBuilder.append("${e.id},\"$escapedTitle\",${e.amount},\"${e.category}\",\"$dateStr\",${e.isRecurringInstance},${e.isIncome},\"$escapedNotes\"\n")
        }
        return csvBuilder.toString()
    }
}

class ExpenseViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ExpenseViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
