package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import com.example.ui.BiometricAuthScreen
import com.example.ui.ExpenseViewModel
import com.example.ui.ExpenseViewModelFactory
import com.example.ui.MainLayout
import com.example.ui.theme.MyApplicationTheme

class MainActivity : FragmentActivity() {

    private val viewModel: ExpenseViewModel by viewModels {
        ExpenseViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val isLocked by viewModel.isLocked.collectAsState()

            MyApplicationTheme(darkTheme = isDarkTheme) {
                if (isLocked) {
                    BiometricAuthScreen(
                        viewModel = viewModel,
                        onSuccess = { viewModel.setLockState(false) }
                    )
                } else {
                    MainLayout(viewModel = viewModel)
                }
            }
        }
    }
}
